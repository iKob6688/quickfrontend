import type { AxiosError, AxiosResponse } from 'axios'

export type ApiErrorPayload =
  | string
  | {
      code?: string
      message: string
      details?: unknown
    }

export interface ApiEnvelope<T> {
  success: boolean
  data?: T
  error?: ApiErrorPayload | null
}

/**
 * JSON-RPC 2.0 response wrapper from Odoo backend
 */
interface JsonRpcResponse<T> {
  jsonrpc: '2.0'
  id: number | string | null
  result?: ApiEnvelope<T>
  error?: ApiErrorPayload
}

/**
 * Normalizes response data to ApiEnvelope format.
 * Handles both JSON-RPC format ({ jsonrpc, result: { success, data, error } })
 * and plain envelope format ({ success, data, error }).
 * 
 * Odoo type="json" routes return:
 * {
 *   "jsonrpc": "2.0",
 *   "id": ...,
 *   "result": {
 *     "success": true,
 *     "data": [...],  // ← Actual data array
 *     "error": null
 *   }
 * }
 */
function normalizeEnvelope<T>(raw: unknown): ApiEnvelope<T> {
  // Handle string responses (Axios might not parse JSON in some cases)
  if (typeof raw === 'string') {
    try {
      raw = JSON.parse(raw)
    } catch {
      // If not JSON, treat as error
      return {
        success: false,
        error: 'Invalid JSON response',
      }
    }
  }

  // Check if it's JSON-RPC format
  if (
    raw &&
    typeof raw === 'object' &&
    'jsonrpc' in raw &&
    (raw as JsonRpcResponse<T>).jsonrpc === '2.0'
  ) {
    const rpc = raw as JsonRpcResponse<T>
    
    // If result exists, use it as the envelope
    // result should be ApiEnvelope<T> = { success: boolean, data?: T, error?: ... }
    if ('result' in rpc && rpc.result) {
      // Ensure result has the expected structure
      if (typeof rpc.result === 'object' && ('success' in rpc.result || 'data' in rpc.result || 'error' in rpc.result)) {
        return rpc.result as ApiEnvelope<T>
      }
      // If result is not an envelope, wrap it
      return {
        success: true,
        data: rpc.result as T,
      }
    }
    
    // If error exists in JSON-RPC, wrap it
    if ('error' in rpc && rpc.error) {
      return {
        success: false,
        error: rpc.error,
      }
    }
    
    // JSON-RPC with no result/error (unlikely but handle gracefully)
    return {
      success: false,
      error: 'JSON-RPC response missing result and error',
    }
  }

  // Otherwise, treat raw as the envelope directly
  return raw as ApiEnvelope<T>
}

export class ApiError extends Error {
  code?: string
  status?: number
  details?: unknown

  constructor(message: string, options?: { code?: string; status?: number; details?: unknown }) {
    super(message)
    this.name = 'ApiError'
    this.code = options?.code
    this.status = options?.status
    this.details = options?.details
  }
}

function safeString(v: unknown): string {
  return typeof v === 'string' ? v : ''
}

function looksLikeHtmlDocument(text: string): boolean {
  const low = text.trim().toLowerCase()
  return low.startsWith('<!doctype html') || low.startsWith('<html')
}

function detectHtmlStatusText(text: string): number | undefined {
  const m = text.match(/<title>\s*(\d{3})\s+/i) || text.match(/<h1>\s*(\d{3})\s+/i)
  return m ? Number(m[1]) : undefined
}

function buildTransportDiagnosticMessage(error: AxiosError<unknown>): string | null {
  const status = error.response?.status
  const rawPayload = error.response?.data
  const configUrl = safeString(error.config?.url)
  const baseURL = safeString(error.config?.baseURL)
  const fullPath = `${baseURL || ''}${configUrl || ''}` || configUrl || 'unknown-url'

  if (typeof rawPayload === 'string' && looksLikeHtmlDocument(rawPayload)) {
    const htmlStatus = detectHtmlStatusText(rawPayload)
    const resolvedStatus = status ?? htmlStatus
    if (resolvedStatus === 404) {
      return (
        `ไม่พบ route ฝั่ง backend (404)\n` +
        `Request: ${fullPath}\n` +
        `สาเหตุที่พบบ่อย: route ยังไม่ถูกโหลดใน Odoo, proxy ชี้ผิด, หรือยิง path ผิด (เช่น /api ซ้ำ)\n` +
        `ตรวจสอบ Network > Request URL และลอง curl endpoint เดียวกัน`
      )
    }
    return (
      `Backend ตอบกลับเป็นหน้า HTML แทน JSON\n` +
      `Request: ${fullPath}\n` +
      `มักเกิดจาก proxy/path ผิด หรือ route ไม่ใช่ Odoo JSON API`
    )
  }

  if (!error.response) {
    if (error.code === 'ERR_CANCELED') {
      return `คำขอถูกยกเลิก (canceled) ระหว่างเรียก API: ${fullPath}`
    }
    if (error.code === 'ECONNABORTED') {
      return `การเชื่อมต่อหมดเวลา (timeout) ระหว่างเรียก API: ${fullPath}`
    }
    if (error.code === 'ERR_NETWORK') {
      return (
        `เชื่อมต่อ API ไม่ได้ (Network/CORS/Proxy)\n` +
        `Request: ${fullPath}\n` +
        `ตรวจสอบ VITE_API_BASE_URL, Vite proxy, และว่า backend เปิดอยู่`
      )
    }
  }

  if (status === 404) {
    return (
      `ไม่พบ endpoint (404)\n` +
      `Request: ${fullPath}\n` +
      `ตรวจสอบ path, proxy, และ route ฝั่ง Odoo`
    )
  }

  return null
}

function parseEnvelopeError(err: ApiErrorPayload | null | undefined) {
  if (!err) {
    return { message: 'Unexpected API response' }
  }

  if (typeof err === 'string') {
    return { message: err }
  }

  // Odoo JSON-RPC error shape often includes { code, message, data: { message, debug, ... } }
  // We prefer the most human-friendly message possible.
  const anyErr: any = err as any
  const nestedMessage =
    typeof anyErr?.data?.message === 'string' && anyErr.data.message.trim().length ? anyErr.data.message : undefined
  const nestedDetails =
    (
      anyErr?.details && typeof anyErr.details === 'object'
        ? {
            ...(anyErr.details as Record<string, unknown>),
            ...(anyErr?.retryable !== undefined ? { retryable: anyErr.retryable } : {}),
            ...(anyErr?.nextSuggestedAction ? { nextSuggestedAction: anyErr.nextSuggestedAction } : {}),
            ...(anyErr?.trace_id ? { trace_id: anyErr.trace_id } : {}),
          }
        : anyErr?.details
    ) ??
    (typeof anyErr?.data?.debug === 'string' ? anyErr.data.debug : undefined) ??
    anyErr?.data

  return {
    message: nestedMessage ?? err.message ?? 'Unexpected API response',
    code: (err as any).code,
    details: nestedDetails,
  }
}

/**
 * Unwraps API response, supporting both JSON-RPC and plain envelope formats.
 * 
 * Odoo type="json" routes return JSON-RPC 2.0:
 * {
 *   "jsonrpc": "2.0",
 *   "id": 1,
 *   "result": {
 *     "success": true,
 *     "data": [...],  // ← This is what we return
 *     "error": null
 *   }
 * }
 * 
 * This function extracts: response.data.result.data
 * 
 * @param response Axios response (response.data may be JSON-RPC or plain envelope)
 * @returns The data payload if successful, throws ApiError otherwise
 */
export function unwrapResponse<T>(response: AxiosResponse<unknown>): T {
  // Debug: Log raw response in development
  if (import.meta.env.DEV) {
    const url = (response.config?.url || 'unknown').toString()
    if (url.includes('purchases') || url.includes('orders') || url.includes('partners')) {
      console.debug('[unwrapResponse] Processing response:', {
        url,
        status: response.status,
        hasData: !!response.data,
        dataType: typeof response.data,
        rawData: response.data,
      })
    }
  }

  const envelope = normalizeEnvelope<T>(response.data)

  // Debug: Log normalized envelope
  if (import.meta.env.DEV) {
    const url = (response.config?.url || 'unknown').toString()
    if (url.includes('purchases') || url.includes('orders') || url.includes('partners')) {
      console.debug('[unwrapResponse] Normalized envelope:', {
        url,
        success: envelope?.success,
        hasData: envelope?.data !== undefined,
        dataType: Array.isArray(envelope?.data) ? 'array' : typeof envelope?.data,
        dataLength: Array.isArray(envelope?.data) ? envelope.data.length : 'N/A',
        firstItem: Array.isArray(envelope?.data) && envelope.data.length > 0 ? envelope.data[0] : null,
      })
    }
  }

  // Success case: envelope has success=true and data is defined
  if (envelope?.success === true && envelope.data !== undefined && envelope.data !== null) {
    return envelope.data as T
  }

  // Error case: extract and throw error
  const { message, code, details } = parseEnvelopeError(envelope?.error)
  throw new ApiError(message, { code, details })
}

export function toApiError(error: unknown): ApiError {
  if (error instanceof ApiError) return error

  const axiosError = error as AxiosError<unknown> | undefined
  const status = axiosError?.response?.status
  const rawPayload = axiosError?.response?.data

  // Prefer transport diagnostics for HTML/error pages before trying envelope parsing.
  // Otherwise HTML 404 from nginx/Odoo becomes generic "Invalid JSON response".
  if (axiosError) {
    const diagnosticMessage = buildTransportDiagnosticMessage(axiosError)
    if (diagnosticMessage) {
      return new ApiError(diagnosticMessage, {
        status,
        details: {
          code: axiosError.code,
          url: axiosError.config?.url,
          baseURL: axiosError.config?.baseURL,
          method: axiosError.config?.method,
        },
      })
    }
  }

  if (rawPayload) {
    const envelope = normalizeEnvelope<unknown>(rawPayload)
    if (!envelope.success && envelope.error) {
      const parsed = parseEnvelopeError(envelope.error)
      return new ApiError(parsed.message, {
        code: parsed.code,
        status,
        details: parsed.details,
      })
    }
  }

  return new ApiError(
    axiosError?.message ?? 'Network error',
    status ? { status } : undefined,
  )
}
