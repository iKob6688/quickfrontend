import { apiClient } from '@/api/client'
import { ApiError, toApiError, unwrapResponse } from '@/api/response'
import { makeRpc } from '@/api/services/rpc'
import { getAccessToken } from '@/lib/authToken'

export type AssistantMode = 'approve_required' | 'auto_safe' | 'plan_only'

export interface AssistantToolCapability {
  name: string
  allowed: boolean
  requires_approval: boolean
}

export interface AssistantReportRoute {
  key: string
  title: string
  route: string
}

export interface AssistantCapabilities {
  enabled: boolean
  show_bot: boolean
  mode: AssistantMode
  features: Record<string, boolean>
  assistant_agent?: {
    enabled: boolean
    login?: string
    display_name?: string
    source?: string
  }
  permissions?: Record<string, { read: boolean; create: boolean; write: boolean }>
  tools: AssistantToolCapability[]
  reports: AssistantReportRoute[]
  session?: {
    company_id?: number
    lang?: string
    user_id?: number
  }
  runtime?: AssistantRuntimeInfo
}

export interface AssistantRuntimeInfo {
  provider: 'local' | 'openai_compat' | 'openclaw' | 'assistant_orchestrator' | string
  enabled: boolean
  model: string
  base_url: string
  ready: boolean
  ready_reason?: string
  planner_provider?: string
  planner_enabled?: boolean
  planner_ready?: boolean
  planner_model?: string
  planner_base_url?: string
  planner_temperature?: number
  planner_max_tokens?: number
  planner_prompt_version?: string
  planner_confirmation_policy?: string
  executor_provider?: string
  executor_enabled?: boolean
  executor_login?: string
  executor_display_name?: string
  executor_user_ready?: boolean
}

export interface AssistantPlanStep {
  id: string
  tool: string
  requires_approval: boolean
  args: Record<string, unknown>
}

export interface AssistantUiAction {
  type: 'OPEN_ROUTE' | 'OPEN_RECORD' | 'SHOW_TOAST' | 'ASK_APPROVAL'
  payload: Record<string, unknown>
}

export interface AssistantRecordRef {
  model: string
  id: number
  name?: string
}

export interface AssistantSourceDescriptor {
  label: string
  route?: string
  model?: string
  id?: number
  count?: number
  date_from?: string
  date_to?: string
  [key: string]: unknown
}

export interface AssistantSafetyInfo {
  db_only_enforced?: boolean
  company_id?: number
  approval_required_count?: number
  [key: string]: unknown
}

export interface AssistantToolProposal {
  id?: string
  tool: string
  category?: string
  auto_safe?: boolean
  allowed?: boolean
  requires_approval?: boolean
  policy?: Record<string, unknown>
  args?: Record<string, unknown>
}

export interface AssistantTokenUsage {
  prompt_tokens?: number
  completion_tokens?: number
  total_tokens?: number
  input_tokens?: number
  output_tokens?: number
  model?: string
}

export interface AssistantChatResponse {
  session_id: string
  nonce?: string
  reply: string
  business_reply?: string
  mode?: 'llm' | 'deterministic_fallback' | string
  trace_id?: string
  warnings?: string[]
  sources?: AssistantSourceDescriptor[]
  safety?: AssistantSafetyInfo
  scope_context?: {
    db?: string
    company_id?: number
  }
  needs_clarification?: boolean
  clarification_fields?: string[]
  tool_proposals?: AssistantToolProposal[]
  usage?: AssistantTokenUsage | Record<string, unknown>
  permission_explanations?: string[]
  classification?: {
    primary_intent?: string
    context_mode?: 'chat' | 'lookup' | 'analytics' | 'document' | 'workflow' | 'mixed' | string
    secondary_intents?: string[]
    confidence?: number
    needs_clarification?: boolean
    user_reply?: string
    reason?: string
  }
  confirmation_request?: {
    doc_type: 'quotation' | 'invoice' | string
    contact_name: string
    product_name: string
    contact_id?: number
    product_id?: number
    contact_candidates?: Array<{ id: number; name: string; vat?: string }>
    product_candidates?: Array<{ id: number; name: string; code?: string; barcode?: string }>
    qty: number
    summary: string
  } | false
  plan: AssistantPlanStep[]
  ui_actions: AssistantUiAction[]
  records: AssistantRecordRef[]
}

export interface AssistantExecuteResponse {
  session_id: string
  reply?: string
  business_reply?: string
  confirmed?: boolean
  mode?: 'llm' | 'deterministic_fallback' | string
  trace_id?: string
  warnings?: string[]
  sources?: AssistantSourceDescriptor[]
  safety?: AssistantSafetyInfo
  scope_context?: {
    db?: string
    company_id?: number
  }
  action_summary?: string[]
  usage?: AssistantTokenUsage | Record<string, unknown>
  permission_explanations?: string[]
  results: Array<{
    plan_id: string
    tool: string
    status: 'success' | 'error' | 'skipped' | 'denied'
    record?: AssistantRecordRef
    error?: string
  }>
  ui_actions: AssistantUiAction[]
  records: AssistantRecordRef[]
}

export interface AssistantTaskItem {
  session_id: string
  title: string
  tool: string
  status: 'draft' | 'planned' | 'executed' | 'failed' | string
  created_at?: string | null
  source: {
    label: string
    route: string
    model?: string | null
    id?: number | null
  }
}

const ENABLE_AI_LEGACY_WEB_FALLBACK =
  import.meta.env.VITE_AI_LEGACY_WEB_FALLBACK === '1' ||
  (import.meta.env.DEV && import.meta.env.VITE_AI_LEGACY_WEB_FALLBACK !== '0')
const WEB_SESSION_TOKEN = '__odoo_web_session__'

async function postWithFallback<T>(apiPath: string, webPath: string, payload: Record<string, unknown>) {
  const rpcPayload = makeRpc(payload)
  // Production-grade default: use canonical /api/th/v1/ai/* contract only.
  // Legacy /web/adt fallback is opt-in by env flag for old deployments.
  const candidates: Array<{ url: string; baseURL?: string }> =
    getAccessToken() === WEB_SESSION_TOKEN ? [{ url: webPath, baseURL: '' }] : [{ url: apiPath }]
  if (ENABLE_AI_LEGACY_WEB_FALLBACK) {
    candidates.push({ url: webPath, baseURL: '' })
  }
  let lastError: unknown = null
  const attempted: string[] = []
  for (const candidate of candidates) {
    const attemptedUrl = `${candidate.baseURL || '(apiClient.baseURL)'}${candidate.url}`
    attempted.push(attemptedUrl)
    try {
      const response = await apiClient.post(
        candidate.url,
        rpcPayload,
        candidate.baseURL !== undefined ? { baseURL: candidate.baseURL } : undefined,
      )
      return unwrapResponse<T>(response)
    } catch (err) {
      const apiErr = toApiError(err)
      // Do not bypass permission/auth/company denial by silently falling back to another route.
      if (
        apiErr.status === 401 ||
        apiErr.status === 403 ||
        apiErr.code === 'scope_forbidden' ||
        apiErr.code === 'company_forbidden' ||
        apiErr.code === 'unauthorized'
      ) {
        throw apiErr
      }
      lastError = err
    }
  }
  if (lastError instanceof Error) {
    const err = new ApiError(`${lastError.message}\nAssistant routes tried: ${attempted.join(' , ')}`)
    ;(err as any).cause = lastError
    throw err
  }
  throw new ApiError(`Assistant route failed. Tried: ${attempted.join(' , ')}`)
}

export async function getAssistantCapabilities(lang?: string) {
  return postWithFallback<AssistantCapabilities>(
    '/th/v1/ai/capabilities',
    '/web/adt/th/v1/ai/capabilities',
    {
      ...(lang ? { lang } : {}),
    },
  )
}

export async function getAssistantRuntime() {
  return postWithFallback<AssistantRuntimeInfo>(
    '/th/v1/ai/runtime',
    '/web/adt/th/v1/ai/runtime',
    {},
  )
}

export async function sendAssistantChat(message: string, context?: Record<string, unknown>) {
  return postWithFallback<AssistantChatResponse>(
    '/th/v1/ai/chat',
    '/web/adt/th/v1/ai/chat',
    {
      message,
      context: context || {},
    },
  )
}

export async function executeAssistantPlan(
  sessionId: string,
  approvedPlanIds: string[],
  nonce?: string,
) {
  return postWithFallback<AssistantExecuteResponse>(
    '/th/v1/ai/execute',
    '/web/adt/th/v1/ai/execute',
    {
      session_id: sessionId,
      approved_plan_ids: approvedPlanIds,
      nonce: nonce || '',
    },
  )
}

export async function getAssistantTasks(limit = 5) {
  return postWithFallback<AssistantTaskItem[]>(
    '/th/v1/ai/tasks',
    '/web/adt/th/v1/ai/tasks',
    { limit },
  )
}

export async function confirmAssistantDocument(payload: {
  session_id: string
  nonce?: string
  confirmed: boolean
  contact_name?: string
  product_name?: string
  contact_id?: number
  product_id?: number
  qty?: number
}) {
  return postWithFallback<AssistantExecuteResponse>(
    '/th/v1/ai/confirm',
    '/web/adt/th/v1/ai/confirm',
    payload,
  )
}
