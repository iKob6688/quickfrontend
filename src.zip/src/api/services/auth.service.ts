import axios from 'axios'
import { apiClient } from '@/api/client'
import { unwrapResponse, ApiError } from '@/api/response'
import { makeRpc } from '@/api/services/rpc'
import { getAccessToken } from '@/lib/authToken'

export interface LoginPayload {
  login: string
  password: string
}

export interface AuthUser {
  id: number
  name: string
  login: string
  email?: string
  locale?: string
  companyName?: string
  instancePublicId?: string
  companyId?: number
  companies?: { id: number; name: string }[]
  isAdmin?: boolean
  is_admin?: boolean
  isSystem?: boolean
  is_system?: boolean
  allowed_scopes?: string[] | string
}

export interface LoginResponse {
  token: string
  user: AuthUser
  companies: { id: number; name: string }[]
}

export interface MeResponse extends AuthUser {
  instancePublicId: string
  companyId: number
  companyName: string
  companies: { id: number; name: string }[]
}

export interface SwitchCompanyResponse {
  companyId: number
  companyName: string
}

export interface RegisterCompanyPayload {
  companyName: string
  adminEmail: string
}

export interface RegisterCompanyResponse {
  company_id: number
  company_name: string
  admin_user_id: number
  admin_login: string
  admin_password: string
}

// NOTE: axios baseURL is VITE_API_BASE_URL (= '/api'), so endpoint paths here must NOT start with '/api'
const basePath = '/th/v1/auth'
const AUTH_TIMEOUT_MS = Number(import.meta.env.VITE_AUTH_TIMEOUT_MS || 15000)
const WEB_SESSION_TOKEN = '__odoo_web_session__'

function uniqueStrings(values: Array<string | null | undefined>) {
  return Array.from(new Set(values.filter((value): value is string => value !== null && value !== undefined)))
}

function normalizeBaseUrl(value?: string | null) {
  if (!value) return null
  const trimmed = value.trim().replace(/\/+$/, '')
  if (!trimmed) return null
  return trimmed
}

function webSessionBaseUrlCandidates() {
  const apiBase = normalizeBaseUrl(import.meta.env.VITE_API_BASE_URL ?? '/api')
  const proxyTarget = normalizeBaseUrl(import.meta.env.VITE_PROXY_TARGET ?? '')

  const candidates: string[] = []

  const addRootAndOdooVariants = (base: string) => {
    const normalized = base.replace(/\/+$/, '')
    candidates.push(normalized)
    if (/\/api$/i.test(normalized)) {
      const root = normalized.replace(/\/api$/i, '')
      candidates.push(root)
      candidates.push(`${root}/odoo`)
      return
    }
    candidates.push(`${normalized}/odoo`)
  }

  // Prefer the same-origin Vite/nginx proxy. Direct Odoo URLs can trigger
  // browser preflight handling that Odoo's native web routes do not accept.
  if (apiBase?.startsWith('/')) {
    candidates.push('')
    candidates.push('/odoo')
  }

  if (apiBase?.startsWith('http://') || apiBase?.startsWith('https://')) {
    addRootAndOdooVariants(apiBase)
  }

  if (proxyTarget && typeof window === 'undefined') {
    addRootAndOdooVariants(proxyTarget)
  }

  return uniqueStrings(candidates)
}

type OdooWebSessionAuthResult = {
  uid?: number
  is_admin?: boolean
  is_system?: boolean
  user_context?: { lang?: string }
  username?: string
  user_name?: string
  db?: string
  user_companies?: {
    current_company?: number | [number, string]
    allowed_companies?: Record<string, { id?: number; name?: string }>
  }
}

const webSessionClient = axios.create({
  withCredentials: true,
})

function currentCompanyTuple(value: number | [number, string] | undefined, allowedCompanies: { id: number; name: string }[]) {
  if (Array.isArray(value)) return { id: Number(value[0] || 0), name: String(value[1] || '') }
  const id = Number(value || 0)
  const match = allowedCompanies.find((company) => company.id === id)
  return { id, name: match?.name || '' }
}

function is404Error(err: unknown) {
  return (err as { response?: { status?: number } })?.response?.status === 404
}

function isRecoverableAuthTransportError(err: unknown) {
  const anyErr = err as { response?: { status?: number }; code?: string }
  const status = anyErr?.response?.status
  if (status === 404 || status === 502 || status === 503 || status === 504) return true
  const code = String(anyErr?.code || '')
  return code === 'ECONNABORTED' || code === 'ERR_NETWORK'
}

async function loginViaWebSession(payload: LoginPayload): Promise<LoginResponse> {
  const db = import.meta.env.VITE_ODOO_DB
  let response: any = null
  let raw: { result?: OdooWebSessionAuthResult; error?: unknown } | undefined
  let result: OdooWebSessionAuthResult | undefined
  let lastErr: unknown = null
  let rootPathErr: unknown = null
  for (const baseURL of webSessionBaseUrlCandidates()) {
    try {
      response = await webSessionClient.post(
        '/web/session/authenticate',
        {
          jsonrpc: '2.0',
          method: 'call',
          params: {
            db,
            login: payload.login,
            password: payload.password,
          },
          id: Date.now(),
        },
        {
          baseURL,
          params: db ? { db } : undefined,
          withCredentials: true,
          maxRedirects: 0,
          timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
        },
      )
      raw = response.data as { result?: OdooWebSessionAuthResult; error?: unknown } | undefined
      result = raw?.result
      if (result?.uid) break
    } catch (e) {
      if (baseURL === '' || /\/api$/i.test(String(import.meta.env.VITE_API_BASE_URL ?? ''))) rootPathErr = e
      lastErr = e
      continue
    }
  }
  if (!response || !result?.uid) {
    // Prefer the root /web failure when available; many deployments do not mount Odoo under /odoo,
    // so the trailing /odoo fallback can hide the real topology mismatch.
    const preferredErr = rootPathErr || lastErr
    if (preferredErr) throw preferredErr instanceof Error ? preferredErr : new ApiError('Odoo web session login failed')
    throw new ApiError('Odoo web session login failed', { status: response?.status, details: raw })
  }
  const allowedCompanies = Object.values(result.user_companies?.allowed_companies ?? {})
    .map((c) => ({ id: Number(c.id || 0), name: c.name || '' }))
    .filter((c) => c.id > 0)
  const currentCompany = currentCompanyTuple(result.user_companies?.current_company, allowedCompanies)
  const user: AuthUser = {
    id: result.uid,
    name: result.user_name || payload.login,
    login: result.username || payload.login,
    locale: result.user_context?.lang,
    companyId: currentCompany.id || undefined,
    companyName: currentCompany.name || undefined,
    companies: allowedCompanies,
    isAdmin: Boolean(result.is_admin),
    isSystem: Boolean(result.is_system),
  }
  return {
    // Session-cookie mode fallback for local/dev when custom auth route is unavailable.
    // Keep a marker token so frontend considers itself authenticated.
    token: WEB_SESSION_TOKEN,
    user,
    companies: allowedCompanies,
  }
}

async function getMeViaWebSession(): Promise<MeResponse> {
  let response: any = null
  let r: any = null
  let lastRaw: any = null
  let lastErr: unknown = null
  let rootPathErr: unknown = null
  for (const baseURL of webSessionBaseUrlCandidates()) {
    try {
      response = await webSessionClient.post(
        '/web/session/get_session_info',
        { jsonrpc: '2.0', method: 'call', params: {}, id: Date.now() },
        {
          baseURL,
          params: import.meta.env.VITE_ODOO_DB ? { db: import.meta.env.VITE_ODOO_DB } : undefined,
          withCredentials: true,
          maxRedirects: 0,
          timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
        },
      )
      const raw = response.data as { result?: any } | undefined
      lastRaw = raw
      r = raw?.result
      if (r?.uid) break
    } catch (e) {
      if (baseURL === '' || /\/api$/i.test(String(import.meta.env.VITE_API_BASE_URL ?? ''))) rootPathErr = e
      lastErr = e
    }
  }
  if (!r?.uid) {
    const preferredErr = rootPathErr || lastErr
    if (preferredErr) throw preferredErr instanceof Error ? preferredErr : new ApiError('Odoo web session not authenticated')
    throw new ApiError('Odoo web session not authenticated', { status: response?.status, details: lastRaw })
  }
  const allowedCompanies = Object.values(r.user_companies?.allowed_companies ?? {})
    .map((c: any) => ({ id: Number(c.id || 0), name: c.name || '' }))
    .filter((c) => c.id > 0)
  const currentCompany = currentCompanyTuple(r.user_companies?.current_company, allowedCompanies)
  return {
    id: r.uid,
    name: r.user_name || r.username || '',
    login: r.username || '',
    email: r.email || undefined,
    locale: r.user_context?.lang,
    companyId: currentCompany.id,
    companyName: currentCompany.name,
    companies: allowedCompanies,
    instancePublicId: currentCompany.id ? String(currentCompany.id) : '',
    isAdmin: Boolean(r.is_admin),
    isSystem: Boolean(r.is_system),
  }
}

async function logoutViaWebSession() {
  let lastErr: unknown = null
  let rootPathErr: unknown = null
  for (const baseURL of webSessionBaseUrlCandidates()) {
    try {
      await webSessionClient.post(
        '/web/session/destroy',
        { jsonrpc: '2.0', method: 'call', params: {}, id: Date.now() },
        {
          baseURL,
          params: import.meta.env.VITE_ODOO_DB ? { db: import.meta.env.VITE_ODOO_DB } : undefined,
          withCredentials: true,
          maxRedirects: 0,
          timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
        },
      )
      return
    } catch (e) {
      if (baseURL === '' || /\/api$/i.test(String(import.meta.env.VITE_API_BASE_URL ?? ''))) rootPathErr = e
      lastErr = e
    }
  }
  const preferredErr = rootPathErr || lastErr
  if (preferredErr) throw preferredErr instanceof Error ? preferredErr : new ApiError('Odoo web session logout failed')
}

export async function login(payload: LoginPayload) {
  const body = makeRpc({
    login: payload.login,
    password: payload.password,
  })
  try {
    const response = await apiClient.post(`${basePath}/login`, body, {
      timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
    })
    return unwrapResponse<LoginResponse>(response)
  } catch (err) {
    if (isRecoverableAuthTransportError(err)) {
      // Fallback when custom auth route is unavailable/slow but Odoo web session exists.
      return loginViaWebSession(payload)
    }
    // Handle 405 Method Not Allowed - usually means VITE_API_BASE_URL is incorrect
    const status = (err as { response?: { status?: number } })?.response?.status
    if (status === 405) {
      const baseURL = import.meta.env.VITE_API_BASE_URL ?? '/api'
      const isRelativeUrl = baseURL.startsWith('/')
      const message =
        `การเชื่อมต่อล้มเหลว (405 Method Not Allowed). ` +
        `กรุณาตรวจสอบการตั้งค่า VITE_API_BASE_URL ในไฟล์ .env\n\n` +
        `ค่าปัจจุบัน: ${baseURL}\n` +
        (isRelativeUrl
          ? `⚠️  สำหรับ server deployment ต้องใช้ full URL เช่น:\n` +
            `   - https://your-server.com/api\n` +
            `   - https://api.example.com\n\n` +
            `รันคำสั่ง: npm run update-env เพื่ออัพเดทการตั้งค่า`
          : `ตรวจสอบว่า URL ถูกต้องและ server รองรับ POST method`)
      throw new ApiError(message, { status: 405, code: 'METHOD_NOT_ALLOWED' })
    }
    throw err
  }
}

export async function getMe() {
  if (getAccessToken() === WEB_SESSION_TOKEN) {
    return getMeViaWebSession()
  }
  const body = makeRpc({})
  try {
    const response = await apiClient.post(`${basePath}/me`, body, {
      timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
    })
    return unwrapResponse<MeResponse>(response)
  } catch (err) {
    if (isRecoverableAuthTransportError(err)) {
      return getMeViaWebSession()
    }
    // Backward-compat: some deployments expose /me as GET only
    const status = (err as { response?: { status?: number } })?.response?.status
    if (status === 405) {
      const response = await apiClient.get(`${basePath}/me`, {
        timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
      })
      return unwrapResponse<MeResponse>(response)
    }
    throw err
  }
}

export async function logout() {
  if (getAccessToken() === WEB_SESSION_TOKEN) {
    await logoutViaWebSession()
    return
  }
  const body = makeRpc({})
  try {
    await apiClient.post(`${basePath}/logout`, body)
  } catch (err) {
    if (is404Error(err)) {
      await logoutViaWebSession()
      return
    }
    throw err
  }
}

export async function switchCompany(companyId: number) {
  const body = makeRpc({ company_id: companyId })
  try {
    const response = await apiClient.post(`${basePath}/switch_company`, body, {
      timeout: Number.isFinite(AUTH_TIMEOUT_MS) && AUTH_TIMEOUT_MS > 0 ? AUTH_TIMEOUT_MS : 15000,
    })
    return unwrapResponse<SwitchCompanyResponse>(response)
  } catch (err) {
    const status = (err as { response?: { status?: number } })?.response?.status
    if (is404Error(err) || status === 405 || isRecoverableAuthTransportError(err)) {
      // Backward compatibility:
      // Some deployments don't expose /auth/switch_company yet.
      // Frontend can still request company-scoped /me via X-Instance-ID and
      // use backend response as the source of truth.
      return { companyId, companyName: '' }
    }
    throw err
  }
}

export async function registerCompany(input: RegisterCompanyPayload) {
  const masterKey = import.meta.env.VITE_REGISTER_MASTER_KEY
  const body = makeRpc({
    master_key: masterKey,
    company_name: input.companyName,
    admin_email: input.adminEmail,
  })
  const response = await apiClient.post(`${basePath}/register_company`, body)
  return unwrapResponse<RegisterCompanyResponse>(response)
}
