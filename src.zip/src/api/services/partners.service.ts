import { apiClient } from '@/api/client'
import { unwrapResponse } from '@/api/response'
import { makeRpc } from '@/api/services/rpc'
import { isAxiosError } from 'axios'

export type PartnerCompanyType = 'company' | 'person'

export interface PartnerSummary {
  id: number
  name: string // display_name
  vat?: string
  phone?: string
  email?: string
  stateId?: number | null
  stateName?: string | null
  active: boolean
  companyType: PartnerCompanyType
}

export interface PartnerListParams {
  q?: string
  company_type?: PartnerCompanyType
  active?: boolean
  offset?: number
  limit?: number
}

export interface PartnerListResponse {
  items: PartnerSummary[]
  total: number
  offset: number
  limit: number
}

// Detail response per docs/api_contract.md (+ backend legacy aliases)
export interface PartnerDetail {
  id: number
  name: string
  displayName: string
  email?: string
  phone?: string
  mobile?: string
  vat?: string
  active: boolean
  companyType: PartnerCompanyType
  // legacy aliases returned by backend
  taxId?: string
  isCompany: boolean
  street?: string
  street2?: string
  city?: string
  district?: string
  subDistrict?: string
  zip?: string
  countryId?: number | null
  countryName?: string | null
  stateId?: number | null
  stateName?: string | null
  provinceId?: number | null
  provinceName?: string | null
  districtId?: number | null
  subDistrictId?: number | null
  tags?: string[]
  vatPriceMode?: 'no_vat' | 'vat_included' | 'vat_excluded'
  branchCode?: string
}

export interface PartnerStateListItem {
  id: number
  name: string
  code?: string
  countryId?: number | null
}

export interface PartnerUpsertPayload {
  company_type: PartnerCompanyType
  name: string
  vat?: string
  phone?: string
  email?: string
  mobile?: string
  street?: string
  street2?: string
  city?: string
  district?: string
  subDistrict?: string
  zip?: string
  countryId?: number | null
  stateId?: number | null
  provinceId?: number | null
  districtId?: number | null
  subDistrictId?: number | null
  tags?: string[]
  payment_term_id?: number
  vatPriceMode?: 'no_vat' | 'vat_included' | 'vat_excluded'
  branchCode?: string
  active?: boolean
}

// Per docs/api_contract.md: backend exposes partners under /api/th/v1/partners/*
const basePath = '/th/v1/partners'

/**
 * Backend response format (from Odoo) - List item
 * Backend may use different field names (isCompany, taxId, display_name, etc.)
 */
interface BackendPartnerSummary {
  id: number
  name?: string
  display_name?: string
  vat?: string
  taxId?: string // Backend alias
  phone?: string
  email?: string
  stateId?: number | null
  stateName?: string | null
  active?: boolean
  isCompany?: boolean // Backend field
  companyType?: PartnerCompanyType // Frontend field (may or may not exist)
  company_type?: PartnerCompanyType | 'company' | 'person' | boolean // Backend variant
  [key: string]: unknown // Allow additional fields
}

/**
 * Backend response format (from Odoo) - Full partner detail
 */
interface BackendPartnerDetail {
  id: number
  name?: string
  displayName?: string
  display_name?: string // Backend alias
  vat?: string
  taxId?: string // Backend alias
  phone?: string
  mobile?: string
  email?: string
  active?: boolean
  isCompany?: boolean // Backend field
  companyType?: PartnerCompanyType // Frontend field (may or may not exist)
  company_type?: PartnerCompanyType | 'company' | 'person' | boolean // Backend variant
  street?: string
  street2?: string
  city?: string
  district?: string
  sub_district?: string
  subDistrict?: string
  zip?: string
  countryId?: number | null
  countryName?: string | null
  stateId?: number | null
  stateName?: string | null
  provinceId?: number | null
  provinceName?: string | null
  districtId?: number | null
  subDistrictId?: number | null
  tags?: string[] | Array<string | { name?: string; display_name?: string }>
  vat_price_mode?: 'no_vat' | 'vat_included' | 'vat_excluded'
  vatPriceMode?: 'no_vat' | 'vat_included' | 'vat_excluded'
  x_vat_price_mode?: 'no_vat' | 'vat_included' | 'vat_excluded'
  branch_code?: string
  branchCode?: string
  x_branch_code?: string
  [key: string]: unknown // Allow additional fields
}

type RawRecord = Record<string, unknown>
type PartnerMutationRaw = BackendPartnerDetail | RawRecord | number

function parseNumber(v: unknown): number {
  if (typeof v === 'number' && Number.isFinite(v)) return v
  if (typeof v === 'string') {
    const n = Number(v.replace(/,/g, '').trim())
    return Number.isFinite(n) ? n : 0
  }
  return 0
}

function toStringList(input: unknown): string[] {
  if (!Array.isArray(input)) return []
  return input
    .map((item) => {
      if (typeof item === 'string') return item.trim()
      if (typeof item === 'number') return Number.isFinite(item) ? String(item) : ''
      if (Array.isArray(item)) {
        const maybeLabel = item[1]
        return typeof maybeLabel === 'string' ? maybeLabel.trim() : ''
      }
      if (item && typeof item === 'object') {
        const record = item as Record<string, unknown>
        const name = record.name ?? record.display_name ?? record.displayName
        return typeof name === 'string' ? name.trim() : ''
      }
      return ''
    })
    .filter(Boolean)
}

function extractPartnerId(raw: unknown): number {
  if (typeof raw === 'number') return Number.isFinite(raw) ? raw : 0
  if (!raw || typeof raw !== 'object') return 0
  const record = raw as RawRecord
  return parseNumber(
    record.id ??
      record.partner_id ??
      record.partnerId ??
      record.contact_id ??
      record.contactId ??
      record.res_id ??
      record.resId ??
      record.record_id ??
      record.recordId,
  )
}

function hasPartnerDetailShape(raw: unknown): raw is BackendPartnerDetail {
  if (!raw || typeof raw !== 'object') return false
  const record = raw as RawRecord
  return (
    extractPartnerId(record) > 0 ||
    typeof record.name === 'string' ||
    typeof record.display_name === 'string' ||
    typeof record.displayName === 'string' ||
    typeof record.email === 'string' ||
    typeof record.phone === 'string'
  )
}

async function findPartnerByPayload(payload: PartnerUpsertPayload): Promise<PartnerDetail | null> {
  const name = String(payload.name || '').trim()
  if (!name) return null

  const listed = await listPartners({
    q: name,
    limit: 10,
    ...(payload.active !== undefined ? { active: payload.active } : {}),
  })

  const exactName = name.toLowerCase()
  const vat = String(payload.vat || '').trim()
  const email = String(payload.email || '').trim().toLowerCase()
  const phone = String(payload.phone || payload.mobile || '').trim()

  const candidate =
    listed.items.find((item) => String(item.name || '').trim().toLowerCase() === exactName) ||
    listed.items.find((item) => Boolean(vat) && item.vat === vat) ||
    listed.items.find((item) => Boolean(email) && String(item.email || '').trim().toLowerCase() === email) ||
    listed.items.find((item) => Boolean(phone) && String(item.phone || '').trim() === phone) ||
    listed.items[0]

  if (!candidate?.id) return null
  return getPartner(candidate.id)
}

async function normalizePartnerMutationResponse(
  raw: PartnerMutationRaw,
  payload: PartnerUpsertPayload,
  fallbackId?: number,
): Promise<PartnerDetail> {
  const resolvedId = extractPartnerId(raw) || fallbackId || 0

  if (resolvedId > 0) {
    try {
      return await getPartner(resolvedId)
    } catch (error) {
      if (import.meta.env.DEV) {
        console.warn('[partners] failed to fetch partner after mutation', {
          resolvedId,
          raw,
          error,
        })
      }
    }
  }

  if (hasPartnerDetailShape(raw)) {
    const mapped = mapBackendPartnerDetailToFrontend({
      ...(raw as BackendPartnerDetail),
      id: resolvedId || extractPartnerId(raw),
    })
    if (mapped.id > 0) return mapped
  }

  const lookedUp = await findPartnerByPayload(payload)
  if (lookedUp) return lookedUp

  throw new Error('สร้างรายชื่อติดต่อสำเร็จ แต่ไม่สามารถ resolve รายการที่สร้างได้')
}

/**
 * Maps backend partner summary to frontend format
 */
function mapBackendPartnerSummaryToFrontend(backend: BackendPartnerSummary): PartnerSummary {
  // Map company type: backend may use isCompany (boolean) or company_type/companyType
  let companyType: PartnerCompanyType = 'person'
  if (backend.companyType) {
    companyType = backend.companyType
  } else if (backend.company_type === 'company' || backend.company_type === 'person') {
    companyType = backend.company_type
  } else if (backend.isCompany === true) {
    companyType = 'company'
  } else if (backend.isCompany === false) {
    companyType = 'person'
  }

  return {
    id: backend.id,
    name: backend.name || backend.display_name || '',
    vat: backend.vat || backend.taxId,
    phone: backend.phone,
    email: backend.email,
    stateId: backend.stateId ?? null,
    stateName: backend.stateName ?? null,
    active: backend.active ?? true,
    companyType,
  }
}

/**
 * Maps backend partner detail to frontend format
 */
function mapBackendPartnerDetailToFrontend(backend: BackendPartnerDetail): PartnerDetail {
  // Map company type
  let companyType: PartnerCompanyType = 'person'
  if (backend.companyType) {
    companyType = backend.companyType
  } else if (backend.company_type === 'company' || backend.company_type === 'person') {
    companyType = backend.company_type
  } else if (backend.isCompany === true) {
    companyType = 'company'
  } else if (backend.isCompany === false) {
    companyType = 'person'
  }

  const name = backend.name || backend.displayName || backend.display_name || ''
  const displayName = backend.displayName || backend.display_name || name

  const district = (backend.district || backend.city || '') as string
  const subDistrict = (backend.subDistrict || backend.sub_district || '') as string

  const vatPriceMode =
    backend.vatPriceMode || backend.vat_price_mode || backend.x_vat_price_mode || undefined
  const branchCode =
    backend.branchCode || backend.branch_code || backend.x_branch_code || undefined

  return {
    id: backend.id,
    name,
    displayName,
    email: backend.email,
    phone: backend.phone,
    mobile: backend.mobile,
    vat: backend.vat || backend.taxId,
    active: backend.active ?? true,
    companyType,
    // Legacy aliases
    taxId: backend.taxId || backend.vat,
    isCompany: backend.isCompany ?? (companyType === 'company'),
    street: backend.street,
    street2: backend.street2,
    city: backend.city,
    district: district || undefined,
    subDistrict: subDistrict || undefined,
    zip: backend.zip,
    countryId: backend.countryId,
    countryName: backend.countryName,
    stateId: backend.stateId ?? null,
    stateName: backend.stateName ?? null,
    provinceId: backend.provinceId ?? null,
    provinceName: backend.provinceName || undefined,
    districtId: backend.districtId ?? null,
    subDistrictId: backend.subDistrictId ?? null,
    tags: toStringList((backend as RawRecord).tags ?? (backend as RawRecord).category_ids ?? (backend as RawRecord).category_id),
    vatPriceMode,
    branchCode,
  }
}

export async function listPartners(params: PartnerListParams) {
  try {
    const response = await apiClient.post(
      `${basePath}/list`,
      makeRpc({
        ...(params.q && { q: params.q }),
        ...(params.q && { search: params.q }), // alias support
        ...(params.active !== undefined && { active: params.active }),
        ...(params.company_type && { company_type: params.company_type }),
        ...(params.offset !== undefined && { offset: params.offset }),
        ...(params.limit !== undefined && { limit: params.limit }),
      }),
    )
    
    // Debug: Log raw response in development
    if (import.meta.env.DEV) {
      console.debug('[listPartners] Raw API response:', {
        url: response.config?.url,
        status: response.status,
        hasData: !!response.data,
        dataType: typeof response.data,
        rawData: response.data,
      })
    }

    // Backend might return array directly or PartnerListResponse
    const data = unwrapResponse<PartnerListResponse | BackendPartnerSummary[]>(response)
  
  // Debug: Log unwrapped data
  if (import.meta.env.DEV) {
    console.debug('[listPartners] Unwrapped data:', {
      isArray: Array.isArray(data),
      hasItems: !Array.isArray(data) && 'items' in data,
      arrayLength: Array.isArray(data) ? data.length : 'N/A',
      firstItem: Array.isArray(data) && data.length > 0 ? data[0] : (!Array.isArray(data) && 'items' in data && Array.isArray(data.items) && data.items.length > 0 ? data.items[0] : null),
    })
  }

    // If it's an array, convert to PartnerListResponse format with mapping
    if (Array.isArray(data)) {
      const mappedItems = data
        .filter((item): item is BackendPartnerSummary => 
          item != null && typeof item === 'object' && 'id' in item
        )
        .map(mapBackendPartnerSummaryToFrontend)
        .filter((item): item is PartnerSummary => 
          item != null && typeof item === 'object' && 'id' in item && 'name' in item
        )

      // Debug: Log mapped items
      if (import.meta.env.DEV) {
        console.debug('[listPartners] Mapped items:', {
          originalCount: data.length,
          mappedCount: mappedItems.length,
          requestedLimit: params.limit,
          sampleItem: mappedItems[0] || null,
        })
      }

      // If we got fewer items than requested limit, this is the last page
      // Otherwise, we don't know the total, so we'll set total to at least offset + items.length + 1
      // to allow pagination to continue (will be updated when we reach the last page)
      const requestedLimit = params.limit || 50
      const isLastPage = mappedItems.length < requestedLimit
      const currentOffset = params.offset || 0
      const loadedCount = currentOffset + mappedItems.length
      
      return {
        items: mappedItems,
        // If this is the last page, total = offset + items.length (actual total)
        // Otherwise, set total to loadedCount + 1 to allow pagination to continue
        total: isLastPage ? loadedCount : loadedCount + 1,
        offset: currentOffset,
        limit: requestedLimit,
      }
    }
  
  // If it's PartnerListResponse, map the items
  if (data && typeof data === 'object' && 'items' in data && Array.isArray(data.items)) {
    const rawItems = data.items as unknown[]
    const backendItems = rawItems.filter(
      (item): item is BackendPartnerSummary => 
        item != null && typeof item === 'object' && 'id' in item
    )
    const mappedItems = backendItems.map(mapBackendPartnerSummaryToFrontend)

    // Debug: Log mapped items
    if (import.meta.env.DEV) {
      console.debug('[listPartners] Mapped PartnerListResponse items:', {
        originalCount: data.items.length,
        mappedCount: mappedItems.length,
        sampleItem: mappedItems[0] || null,
      })
    }

    return {
      items: mappedItems,
      total: data.total ?? mappedItems.length,
      offset: data.offset ?? (params.offset || 0),
      limit: data.limit ?? (params.limit || mappedItems.length),
    }
  }
  
    // Fallback: return as-is (should not happen)
    console.warn('[listPartners] Unexpected response format:', data)
    return {
      items: [],
      total: 0,
      offset: params.offset || 0,
      limit: params.limit || 0,
    }
  } catch (error) {
    if (isAxiosError(error)) {
      // React Query may cancel in-flight requests while typing/searching.
      if (error.code === 'ERR_CANCELED') {
        if (import.meta.env.DEV) console.debug('[listPartners] request canceled')
        throw error
      }

      if (error.code === 'ECONNABORTED') {
        throw new Error(
          'โหลดรายชื่อติดต่อไม่ทันเวลา (timeout). ตรวจสอบการเชื่อมต่อ backend/proxy และลองใหม่อีกครั้ง'
        )
      }
    }

    if (error instanceof Error) {
      const enhancedError = new Error(
        `ไม่สามารถโหลดรายชื่อติดต่อได้: ${error.message}. ` +
        `ตรวจสอบ endpoint /api/th/v1/partners/list และ VITE_PROXY_TARGET`
      )
      enhancedError.name = error.name
      enhancedError.stack = error.stack
      throw enhancedError
    }

    throw error
  }
}

export async function getPartner(id: number) {
  try {
    const response = await apiClient.post(`${basePath}/${id}`, makeRpc({}))

    // Debug: Log raw response in development
    if (import.meta.env.DEV) {
      console.debug('[getPartner] Raw API response:', {
        id,
        url: response.config?.url,
        status: response.status,
        hasData: !!response.data,
        dataType: typeof response.data,
        rawData: response.data,
      })
    }

    const data = unwrapResponse<BackendPartnerDetail>(response)

    // Debug: Log unwrapped data
    if (import.meta.env.DEV) {
      console.debug('[getPartner] Unwrapped data:', {
        id,
        hasId: 'id' in data,
        hasName: 'name' in data || 'display_name' in data || 'displayName' in data,
        hasIsCompany: 'isCompany' in data,
        hasCompanyType: 'companyType' in data || 'company_type' in data,
        rawData: data,
      })
    }

    const mapped = mapBackendPartnerDetailToFrontend(data)

    // Debug: Log mapped data
    if (import.meta.env.DEV) {
      console.debug('[getPartner] Mapped partner:', {
        id,
        mapped,
      })
    }

    return mapped
  } catch (error) {
    if (isAxiosError(error)) {
      if (error.code === 'ERR_CANCELED') {
        if (import.meta.env.DEV) console.debug('[getPartner] request canceled')
        throw error
      }
      if (error.code === 'ECONNABORTED') {
        throw new Error('โหลดข้อมูลลูกค้าไม่ทันเวลา (timeout). ตรวจสอบ backend/proxy แล้วลองใหม่')
      }
    }
    throw error
  }
}

export async function createPartner(payload: PartnerUpsertPayload) {
  const response = await apiClient.post(
    `${basePath}/create`,
    makeRpc({
      company_type: payload.company_type,
      name: payload.name,
      vat: payload.vat,
      phone: payload.phone,
      mobile: payload.mobile,
      email: payload.email,
      street: payload.street,
      street2: payload.street2,
      city: payload.district || payload.city,
      district: payload.district,
      subDistrict: payload.subDistrict,
      zip: payload.zip,
      countryId: payload.countryId,
      stateId: payload.stateId,
      provinceId: payload.provinceId,
      districtId: payload.districtId,
      subDistrictId: payload.subDistrictId,
      tags: payload.tags,
      payment_term_id: payload.payment_term_id,
      vat_price_mode: payload.vatPriceMode,
      vatPriceMode: payload.vatPriceMode,
      x_vat_price_mode: payload.vatPriceMode,
      branch_code: payload.branchCode,
      branchCode: payload.branchCode,
      x_branch_code: payload.branchCode,
      ...(payload.active !== undefined ? { active: payload.active } : {}),
    }),
  )
  const raw = unwrapResponse<PartnerMutationRaw>(response)
  return normalizePartnerMutationResponse(raw, payload)
}

export async function updatePartner(id: number, payload: PartnerUpsertPayload) {
  const response = await apiClient.post(
    `${basePath}/${id}/update`,
    makeRpc({
      company_type: payload.company_type,
      name: payload.name,
      vat: payload.vat,
      phone: payload.phone,
      mobile: payload.mobile,
      email: payload.email,
      street: payload.street,
      street2: payload.street2,
      city: payload.district || payload.city,
      district: payload.district,
      subDistrict: payload.subDistrict,
      zip: payload.zip,
      countryId: payload.countryId,
      stateId: payload.stateId,
      provinceId: payload.provinceId,
      districtId: payload.districtId,
      subDistrictId: payload.subDistrictId,
      tags: payload.tags,
      payment_term_id: payload.payment_term_id,
      vat_price_mode: payload.vatPriceMode,
      vatPriceMode: payload.vatPriceMode,
      x_vat_price_mode: payload.vatPriceMode,
      branch_code: payload.branchCode,
      branchCode: payload.branchCode,
      x_branch_code: payload.branchCode,
      ...(payload.active !== undefined ? { active: payload.active } : {}),
    }),
  )
  const raw = unwrapResponse<PartnerMutationRaw>(response)
  return normalizePartnerMutationResponse(raw, payload, id)
}

export async function archivePartner(id: number) {
  const response = await apiClient.post(
    `${basePath}/${id}/update`,
    makeRpc({ active: false }),
  )
  return unwrapResponse<PartnerDetail>(response)
}

export async function unarchivePartner(id: number) {
  const response = await apiClient.post(
    `${basePath}/${id}/update`,
    makeRpc({ active: true }),
  )
  return unwrapResponse<PartnerDetail>(response)
}

export async function setPartnerActive(id: number, active: boolean) {
  const response = await apiClient.post(
    `${basePath}/${id}/update`,
    makeRpc({ active }),
  )
  return unwrapResponse<PartnerDetail>(response)
}

export async function setPartnersActive(ids: number[], active: boolean) {
  // Avoid firing unbounded concurrent requests.
  const pageSize = 25
  const ok: number[] = []
  const failed: Array<{ id: number; message: string }> = []

  for (let i = 0; i < ids.length; i += pageSize) {
    const chunk = ids.slice(i, i + pageSize)
    const settled = await Promise.allSettled(chunk.map((id) => setPartnerActive(id, active)))
    settled.forEach((r, idx) => {
      const id = chunk[idx]
      if (r.status === 'fulfilled') ok.push(id)
      else failed.push({ id, message: r.reason instanceof Error ? r.reason.message : 'Unknown error' })
    })
  }

  return { ok, failed }
}

export async function listPartnerStates(params?: { countryId?: number | null; search?: string; limit?: number }) {
  const response = await apiClient.post(
    `${basePath}/states`,
    makeRpc({
      ...(params?.countryId ? { country_id: params.countryId } : {}),
      ...(params?.search ? { search: params.search } : {}),
      ...(params?.limit ? { limit: params.limit } : {}),
    }),
  )
  const data = unwrapResponse<Array<Record<string, unknown>>>(response)
  return (Array.isArray(data) ? data : []).map((item) => ({
    id: Number(item.id || 0),
    name: String(item.name || ''),
    code: item.code ? String(item.code) : undefined,
    countryId: item.countryId ? Number(item.countryId) : null,
  })).filter((item) => item.id > 0 && item.name)
}

export interface PartnerQuery {
  q?: string
  active?: boolean
  company_type?: PartnerCompanyType
}

/**
 * Bulk update "all matching results" by paging through /partners/list.
 * This is v1-safe even without a backend bulk endpoint.
 */
export async function setPartnersActiveByQuery(
  query: PartnerQuery,
  active: boolean,
  options?: { excludeIds?: number[]; pageSize?: number; maxItems?: number },
) {
  const exclude = new Set(options?.excludeIds ?? [])
  const pageSize = options?.pageSize ?? 200
  const maxItems = options?.maxItems ?? 5000

  const ids: number[] = []
  let offset = 0
  let total = 0

  while (true) {
    const res = await listPartners({
      ...query,
      limit: pageSize,
      offset,
    })
    total = res.total
    const pageIds = res.items.map((p) => p.id).filter((id) => !exclude.has(id))
    ids.push(...pageIds)

    offset += res.items.length
    if (res.items.length === 0) break
    if (offset >= res.total) break
    if (ids.length >= maxItems) break
  }

  const processedIds = ids.slice(0, maxItems)
  const { ok, failed } = await setPartnersActive(processedIds, active)
  return {
    totalMatched: total,
    processed: processedIds.length,
    ok,
    failed,
    truncated: total > maxItems,
  }
}
