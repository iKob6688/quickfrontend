import { useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useInfiniteQuery, useQuery } from '@tanstack/react-query'
import { Spinner } from 'react-bootstrap'
import { PageHeader } from '@/components/ui/PageHeader'
import { Button } from '@/components/ui/Button'
import { Tabs } from '@/components/ui/Tabs'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { DataTable, type Column } from '@/components/ui/DataTable'
import { useDebouncedValue } from '@/lib/useDebouncedValue'
import { listSalesOrders, type SalesOrderStatus } from '@/api/services/sales-orders.service'
import { useAppDateFormatter } from '@/lib/dateFormat'
import { useSettingsStore } from '@/app/core/storage/settingsStore'

type StatusTab = 'all' | SalesOrderStatus

export function SalesOrdersListPage() {
  const navigate = useNavigate()
  const formatDate = useAppDateFormatter()
  const scanSlipEnabled = useSettingsStore((state) => state.settings.scanSlipEnabled)
  const [searchParams] = useSearchParams()
  const typeParam = searchParams.get('type')
  const forcedOrderType = typeParam === 'sale' ? 'sale' : typeParam === 'quotation' ? 'quotation' : undefined
  const [tab, setTab] = useState<StatusTab>('all')
  const [jobFilter, setJobFilter] = useState<'all' | 'accounting' | 'closing' | 'registration' | 'other'>('all')
  const [q, setQ] = useState('')
  const qDebounced = useDebouncedValue(q, 300)
  const limit = 30

  const query = useInfiniteQuery({
    queryKey: ['salesOrders', tab, forcedOrderType, qDebounced, limit],
    initialPageParam: 0,
    queryFn: ({ pageParam }) =>
      listSalesOrders({
        status: tab === 'all' ? undefined : tab,
        orderType: forcedOrderType,
        search: qDebounced || undefined,
        limit,
        offset: pageParam,
      }),
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage || lastPage.length < limit) return undefined
      return allPages.reduce((acc, page) => acc + page.length, 0)
    },
    staleTime: 30_000,
  })

  const orders = useMemo(() => query.data?.pages.flatMap((p) => p) ?? [], [query.data?.pages])
  const countsQuery = useQuery({
    queryKey: ['salesOrders-counts', forcedOrderType, qDebounced],
    queryFn: () =>
      listSalesOrders({
        orderType: forcedOrderType,
        search: qDebounced || undefined,
        limit: 1000,
        offset: 0,
      }),
    staleTime: 30_000,
  })

  const statusCounts = useMemo(() => {
    const base = { all: 0, draft: 0, sent: 0, sale: 0, done: 0, cancel: 0 } as Record<StatusTab, number>
    for (const row of countsQuery.data ?? []) {
      base.all += 1
      base[row.status] += 1
    }
    return base
  }, [countsQuery.data])

  const filteredOrders = useMemo(() => {
    if (jobFilter === 'all') return orders
    return orders.filter((order) => {
      if (order.jobCategory && order.jobCategory === jobFilter) return true
      const text = `${order.number} ${order.partnerName} ${order.notes ?? ''}`.toLowerCase()
      if (jobFilter === 'closing') return /ปิดงบ|financial statement|close company|fs\b/.test(text)
      if (jobFilter === 'registration') return /จดทะเบียน|registration|boi|fbl|visa|work permit|license/.test(text)
      if (jobFilter === 'accounting') return /บัญชี|account|bookkeep|outsourcing/.test(text)
      return !/ปิดงบ|financial statement|close company|fs\b|จดทะเบียน|registration|boi|fbl|visa|work permit|license|บัญชี|account|bookkeep|outsourcing/.test(text)
    })
  }, [orders, jobFilter])

  const rows = useMemo(
    () =>
      filteredOrders.map((order) => ({
        id: order.id,
        number: order.number,
        orderType: order.orderType,
        customer: order.partnerName,
        date: formatDate(order.orderDate),
        total: order.total,
        status: order.status,
      })),
    [filteredOrders, formatDate],
  )

  const columns: Column<(typeof rows)[number]>[] = [
    {
      key: 'number',
      header: 'เลขที่เอกสาร',
      className: 'text-nowrap',
      cell: (r) => (
        <button
          type="button"
          className="btn btn-link p-0 fw-semibold text-primary text-decoration-none font-monospace"
          onClick={() => navigate(`/sales/orders/${r.id}`)}
        >
          {r.number || `ร่าง #${r.id}`}
        </button>
      ),
    },
    {
      key: 'orderType',
      header: 'ประเภท',
      className: 'text-nowrap',
      cell: (r) => <Badge tone={r.orderType === 'sale' ? 'blue' : 'gray'}>{r.orderType === 'sale' ? 'Sale Order' : 'ใบเสนอราคา'}</Badge>,
    },
    { key: 'customer', header: 'ลูกค้า', cell: (r) => <span>{r.customer}</span> },
    { key: 'date', header: 'วันที่เอกสาร', className: 'text-nowrap', cell: (r) => <span>{r.date}</span> },
    {
      key: 'total',
      header: 'มูลค่ารวม',
      className: 'text-end',
      cell: (r) => (
        <span className="fw-semibold font-monospace">
          {r.total.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </span>
      ),
    },
    {
      key: 'status',
      header: 'สถานะ',
      className: 'text-nowrap',
      cell: (r) => {
        const tone =
          r.status === 'done'
            ? 'green'
            : r.status === 'sale'
              ? 'blue'
              : r.status === 'sent'
                ? 'amber'
                : r.status === 'cancel'
                  ? 'red'
                  : 'gray'
        const label =
          r.status === 'done'
            ? 'เสร็จสิ้น'
            : r.status === 'sale'
              ? 'ยืนยันแล้ว'
              : r.status === 'sent'
                ? 'ส่งแล้ว'
                : r.status === 'cancel'
                  ? 'ยกเลิก'
                  : 'ร่าง'
        return <Badge tone={tone}>{label}</Badge>
      },
    },
  ]

  return (
    <div>
      <PageHeader
        title="ใบเสนอราคา / Sale Order"
        subtitle={
          forcedOrderType === 'quotation'
            ? 'โหมดใบเสนอราคา'
            : forcedOrderType === 'sale'
              ? 'โหมด Sale Order'
              : 'จัดการใบเสนอราคาและคำสั่งขาย'
        }
        breadcrumb="รายรับ · ใบเสนอราคา · Sale Order"
        actions={
          <div className="d-flex align-items-center gap-2">
            <Button size="sm" variant="ghost" onClick={() => navigate('/products')}>
              สินค้า
            </Button>
            <Button size="sm" variant="ghost" onClick={() => navigate('/products/new')}>
              + เพิ่มสินค้า
            </Button>
            <Button size="sm" variant="secondary" onClick={() => navigate('/sales/orders/new?orderType=quotation')}>
              + สร้างใบเสนอราคา
            </Button>
            {scanSlipEnabled ? (
              <Button size="sm" variant="secondary" onClick={() => navigate('/accounting/pending-reconcile?source=sales&upload=1')}>
                <i className="bi bi-upc-scan me-1" />
                Scan Slip
              </Button>
            ) : null}
            <Button size="sm" onClick={() => navigate('/sales/orders/new?orderType=sale')}>
              + สร้าง Sale Order
            </Button>
          </div>
        }
      />

      <div className="mb-4 d-flex flex-column gap-3 flex-sm-row align-items-sm-center justify-content-sm-between">
        <Tabs
          value={tab}
          onChange={(next) => setTab(next as StatusTab)}
          items={[
            { key: 'all', label: 'ทั้งหมด', count: statusCounts.all },
            { key: 'draft', label: 'ร่าง', count: statusCounts.draft },
            { key: 'sent', label: 'ส่งแล้ว', count: statusCounts.sent },
            { key: 'sale', label: 'ยืนยันแล้ว', count: statusCounts.sale },
            { key: 'done', label: 'เสร็จสิ้น', count: statusCounts.done },
            { key: 'cancel', label: 'ยกเลิก', count: statusCounts.cancel },
          ]}
        />
        <div className="d-flex flex-column flex-sm-row gap-2 w-100 justify-content-sm-end" style={{ maxWidth: 720 }}>
          <select
            className="form-select"
            style={{ maxWidth: 240 }}
            value={jobFilter}
            onChange={(e) => setJobFilter(e.target.value as typeof jobFilter)}
            aria-label="ตัวกรองประเภทงาน"
          >
            <option value="all">งานทั้งหมด</option>
            <option value="closing">ปิดงบ / งบการเงิน</option>
            <option value="accounting">ทำบัญชี / Accounting</option>
            <option value="registration">จดทะเบียน / License / VISA</option>
            <option value="other">อื่นๆ</option>
          </select>
          <div className="w-100" style={{ maxWidth: 420 }}>
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ค้นหาเลขที่เอกสาร / ลูกค้า"
              leftAdornment={<i className="bi bi-search"></i>}
            />
          </div>
        </div>
      </div>

      {query.isLoading ? (
        <div className="d-flex justify-content-center align-items-center py-5">
          <Spinner animation="border" role="status" />
          <span className="ms-3">กำลังโหลดข้อมูล...</span>
        </div>
      ) : query.isError ? (
        <div className="alert alert-danger">
          <p className="fw-semibold mb-2">โหลดใบเสนอราคา / Sale Order ไม่สำเร็จ</p>
          <p className="small mb-2">{query.error instanceof Error ? query.error.message : 'Unknown error'}</p>
          <p className="small mb-3 mb-0">
            ตรวจสอบ backend endpoint <code>/api/th/v1/sales/orders/*</code> ในโมดูล <code>adt_th_api</code>
          </p>
        </div>
      ) : (
        <div className="d-flex flex-column gap-3">
          <DataTable
            title="รายการใบเสนอราคา / Sale Order"
            right={
              <Button size="sm" variant="ghost" onClick={() => query.refetch()}>
                <i className="bi bi-arrow-clockwise me-1"></i>
                รีเฟรช
              </Button>
            }
            columns={columns}
            rows={rows}
            rowKey={(row) => row.id}
            empty={
              <div>
                <p className="h6 fw-semibold mb-2">ยังไม่มีข้อมูล</p>
                <p className="small text-muted mb-0">
                  {qDebounced || jobFilter !== 'all' ? 'ไม่พบข้อมูลตามตัวกรองที่เลือก' : 'ยังไม่มีใบเสนอราคา/Sale Order ในระบบ'}
                </p>
              </div>
            }
          />

          <div className="d-flex justify-content-between align-items-center">
            <div className="small text-muted">
              แสดงแล้ว {rows.length} รายการ
              {jobFilter !== 'all' && (
                <span className="ms-2">
                  • ตัวกรองงาน:{' '}
                  <span className="fw-semibold">
                    {jobFilter === 'closing'
                      ? 'ปิดงบ / งบการเงิน'
                      : jobFilter === 'accounting'
                        ? 'ทำบัญชี / Accounting'
                        : jobFilter === 'registration'
                          ? 'จดทะเบียน / License / VISA'
                          : 'อื่นๆ'}
                  </span>
                </span>
              )}
            </div>
            {query.hasNextPage ? (
              <Button
                size="sm"
                variant="secondary"
                onClick={() => query.fetchNextPage()}
                isLoading={query.isFetchingNextPage}
              >
                โหลดเพิ่ม
              </Button>
            ) : (
              <div className="small text-muted">ครบแล้ว</div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
