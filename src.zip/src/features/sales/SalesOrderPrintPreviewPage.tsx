import { useMemo } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Alert, Spinner } from 'react-bootstrap'
import { Button } from '@/components/ui/Button'
import { getSalesOrder, type SalesOrder, type SalesOrderAttachment, type SalesOrderLine } from '@/api/services/sales-orders.service'
import { getPartner } from '@/api/services/partners.service'
import { formatAppDate, formatAppDateTime } from '@/lib/dateFormat'
import { calculateSalesOrderTotals } from '@/lib/salesOrderTotals'
import { getSalesOrderCustomerContactText, getSalesOrderCustomerDisplayName } from '@/lib/salesOrderPresentation'
import { useSettingsStore } from '@/app/core/storage/settingsStore'

export function SalesOrderPrintPreviewPage() {
  const navigate = useNavigate()
  const settings = useSettingsStore((state) => state.settings)
  const params = useParams()
  const id = useMemo(() => Number(params.id), [params.id])

  const query = useQuery({
    queryKey: ['salesOrder', 'printPreview', id],
    enabled: Number.isFinite(id) && id > 0,
    queryFn: () => getSalesOrder(id),
    staleTime: 30_000,
  })

  const partnerQuery = useQuery({
    queryKey: ['partner', 'printPreview', query.data?.partnerId],
    enabled: typeof query.data?.partnerId === 'number' && query.data.partnerId > 0,
    queryFn: () => getPartner(query.data!.partnerId as number),
    staleTime: 60_000,
  })

  const orderTotals = useMemo(
    () =>
      calculateSalesOrderTotals(query.data?.lines || [], {
        vatEnabled: Boolean(query.data?.vatEnabled),
        vatRate: query.data?.vatRate ?? 0,
        withholdingTaxEnabled: Boolean(query.data?.withholdingTaxEnabled),
        withholdingTaxRate: query.data?.withholdingTaxRate ?? 0,
      }),
    [query.data?.lines, query.data?.vatEnabled, query.data?.vatRate, query.data?.withholdingTaxEnabled, query.data?.withholdingTaxRate],
  )

  if (!Number.isFinite(id) || id <= 0) {
    return <Alert variant="danger" className="m-3">URL ไม่ถูกต้อง</Alert>
  }

  if (query.isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center py-5">
        <Spinner animation="border" size="sm" />
        <span className="ms-2">กำลังโหลดเอกสาร...</span>
      </div>
    )
  }

  if (query.isError || !query.data) {
    return (
      <div className="container py-4">
        <Alert variant="danger">
          {query.error instanceof Error ? query.error.message : 'โหลดเอกสารไม่สำเร็จ'}
        </Alert>
        <Button variant="secondary" onClick={() => navigate(`/sales/orders/${id}`)}>
          กลับหน้ารายละเอียด
        </Button>
      </div>
    )
  }

  const order = query.data as SalesOrder
  const orderLines: SalesOrderLine[] = Array.isArray(order.lines) ? order.lines : []
  const attachments: SalesOrderAttachment[] = Array.isArray(order.attachments) ? order.attachments : []
  const documentLabel = order.orderType === 'sale' ? 'Sale Order' : 'ใบเสนอราคา'
  const formatPrintDate = (value?: string | Date | null, fallback = '-') =>
    formatAppDate(value, { ...settings, dateDisplayFormat: 'DD-MM-YYYY' }, fallback)
  const formatPrintDateTime = (value?: string | Date | null, fallback = '-') =>
    formatAppDateTime(value, { ...settings, dateDisplayFormat: 'DD-MM-YYYY' }, fallback)
  const partner = partnerQuery.data
  const partnerAddress = [partner?.street, partner?.street2, [partner?.city, partner?.zip].filter(Boolean).join(' '), partner?.countryName]
    .filter(Boolean)
    .join(' ')
  const customerDisplayName = getSalesOrderCustomerDisplayName(order)
  const customerAddress = order.customerAddressText || partnerAddress
  const customerContact = getSalesOrderCustomerContactText(order)
  return (
    <div className="container py-4 qf-so-print">
      <div className="d-flex gap-2 justify-content-end mb-3 d-print-none">
        <Button size="sm" variant="secondary" onClick={() => navigate(`/sales/orders/${id}`)}>
          กลับหน้ารายละเอียด
        </Button>
        <Button size="sm" onClick={() => window.print()}>
          พิมพ์เอกสาร
        </Button>
      </div>

      <div className="bg-white border rounded-3 p-4 p-md-5" style={{ maxWidth: 980, margin: '0 auto' }}>
        <style>
          {`@media print {
            .qf-so-print table tr, .qf-so-print table td, .qf-so-print table th { break-inside: avoid; page-break-inside: avoid; }
            .qf-so-print .qf-so-print__summary { break-inside: avoid; page-break-inside: avoid; }
            .qf-so-print .qf-so-print__meta { break-inside: avoid; page-break-inside: avoid; }
          }`}
        </style>
        <div className="d-flex justify-content-between align-items-start mb-4">
          <div>
            <h1 className="h3 mb-1">{documentLabel}</h1>
            <div className="text-muted">{order.number || `#${order.id}`}</div>
          </div>
          <div className="text-end small">
            <div>วันที่เอกสาร: {formatPrintDate(order.orderDate, '-')}</div>
            <div>วันหมดอายุ: {formatPrintDate(order.validityDate, '-')}</div>
            <div>สถานะ: {order.status}</div>
          </div>
        </div>

        <div className="rounded border p-2 small mb-3 qf-so-print__meta">
          <div className="row g-2">
            <div className="col-md-4"><span className="text-muted">เลขที่เอกสาร:</span> <span className="font-monospace fw-semibold">{order.number || `#${order.id}`}</span></div>
            <div className="col-md-4"><span className="text-muted">ประเภทเอกสาร:</span> <span className="font-monospace fw-semibold">{documentLabel}</span></div>
            <div className="col-md-4"><span className="text-muted">สินค้า/บริการ:</span> <span className="fw-semibold">{orderLines.find((line) => line.description?.trim())?.description || '-'}</span></div>
          </div>
        </div>

        <div className="row g-3 mb-3">
          <div className="col-md-7">
            <div className="small text-muted">ลูกค้า</div>
            <div className="fw-semibold">{customerDisplayName}</div>
            {customerAddress ? <div className="small mt-1">{customerAddress}</div> : null}
            {customerContact ? <div className="small text-muted mt-1">{customerContact}</div> : null}
            {!customerContact && (partner?.phone || partner?.email) ? (
              <div className="small text-muted mt-1">{[partner?.phone, partner?.email].filter(Boolean).join(' · ')}</div>
            ) : null}
            {(order.customerTaxIdText || partner?.vat || partner?.taxId) ? (
              <div className="small text-muted mt-1">Tax ID: {order.customerTaxIdText || partner?.vat || partner?.taxId}</div>
            ) : null}
          </div>
          <div className="col-md-5">
            {order.notes ? (
              <div>
                <div className="small text-muted">หมายเหตุ</div>
                <div className="small" style={{ whiteSpace: 'pre-line' }}>{order.notes}</div>
              </div>
            ) : null}
          </div>
        </div>

        <table className="table table-bordered align-middle">
          <thead className="table-light">
            <tr>
              <th style={{ width: '46%' }}>รายละเอียด</th>
              <th className="text-end" style={{ width: '14%' }}>จำนวน</th>
              <th className="text-end" style={{ width: '20%' }}>ราคาต่อหน่วย</th>
              <th className="text-end" style={{ width: '20%' }}>ยอดรวม</th>
            </tr>
          </thead>
          <tbody>
            {orderLines.map((line: SalesOrderLine, idx: number) =>
              line.lineType === 'section' || line.lineType === 'note' ? (
                <tr key={`${line.productId || 'item'}-${idx}`} className={line.lineType === 'section' ? 'table-primary' : 'table-light'}>
                  <td colSpan={4}>
                    <div className={line.lineType === 'section' ? 'fw-semibold' : 'text-muted'}>
                      {line.lineType === 'section' ? 'หัวข้อ' : 'หมายเหตุ'}
                    </div>
                    <div className={line.lineType === 'section' ? 'fw-semibold' : 'small text-muted'}>
                      {line.description || (line.lineType === 'section' ? 'หัวข้อ' : 'หมายเหตุ')}
                    </div>
                  </td>
                </tr>
              ) : (
                <tr key={`${line.productId || 'item'}-${idx}`}>
                  <td>{line.description || '-'}</td>
                  <td className="text-end">{(line.quantity || 0).toLocaleString('th-TH')}</td>
                  <td className="text-end">{(line.unitPrice || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                  <td className="text-end fw-semibold">{(line.total || 0).toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                </tr>
              ),
            )}
            {orderLines.length === 0 && (
              <tr>
                <td colSpan={4} className="text-center text-muted">ไม่มีรายการสินค้า</td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="d-flex justify-content-end mt-3 qf-so-print__summary">
          <div style={{ minWidth: 320 }}>
            <div className="d-flex justify-content-between py-1 border-bottom">
              <span>ยอดก่อนส่วนลด</span>
              <span className="font-monospace">{orderTotals.grossSubtotal.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="d-flex justify-content-between py-1 border-bottom">
              <span>ส่วนลด</span>
              <span className="font-monospace">{orderTotals.discountAmount.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="d-flex justify-content-between py-1 border-bottom">
              <span>หลังหักส่วนลด</span>
              <span className="font-monospace">{orderTotals.afterDiscount.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="d-flex justify-content-between py-1 border-bottom">
              <span>VAT</span>
              <span className="font-monospace">{orderTotals.vatAmount.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="d-flex justify-content-between py-1 border-bottom">
              <span>หัก ณ ที่จ่าย</span>
              <span className="font-monospace">{orderTotals.withholdingAmount.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div className="d-flex justify-content-between py-2 fw-bold">
              <span>ยอดรวมสุทธิ</span>
              <span className="font-monospace">{orderTotals.grandTotal.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        {(order.attachments?.length ?? 0) > 0 ? (
          <div className="mt-4">
            <div className="small text-muted mb-2">เอกสารแนบ</div>
            <ul className="small mb-0">
              {attachments.map((attachment, idx) => (
                <li key={`${attachment.name || 'attachment'}-${idx}`}>
                  {attachment.name || 'เอกสารแนบ'}
                  {attachment.size ? ` (${Math.round(attachment.size / 1024)} KB)` : ''}
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <div className="mt-4 pt-3 border-top small text-muted d-flex justify-content-between">
          <div>Ref: {order.number || `#${order.id}`}</div>
          <div>Printed: {formatPrintDateTime(new Date())}</div>
        </div>
      </div>
    </div>
  )
}
