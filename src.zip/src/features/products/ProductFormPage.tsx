import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Alert, Form } from 'react-bootstrap'
import { PageHeader } from '@/components/ui/PageHeader'
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Label } from '@/components/ui/Label'
import { Tabs } from '@/components/ui/Tabs'
import { toast } from '@/lib/toastStore'
import {
  createProduct,
  getProduct,
  getProductAdminMeta,
  updateProduct,
  type ProductUpsertPayload,
} from '@/api/services/products.service'
import { getDefaultVatTaxId, listVatTaxes } from '@/api/services/taxes.service'

const DEFAULT_FORM: ProductUpsertPayload = {
  name: '',
  defaultCode: '',
  barcode: '',
  listPrice: 0,
  saleOk: true,
  purchaseOk: true,
  active: true,
  description: '',
}

function productImageSrc(row: { id?: number | null; image128?: string | null; imageUrl?: string | null }) {
  if (row.image128) return `data:image/png;base64,${row.image128}`
  if (row.imageUrl) return row.imageUrl
  if (row.id) return `/web/image?model=product.product&id=${row.id}&field=image_128`
  return '/vite.svg'
}

export function ProductFormPage() {
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const { id } = useParams<{ id: string }>()
  const isEdit = Boolean(id)
  const productId = id ? Number(id) : null

  const [errorText, setErrorText] = useState<string | null>(null)
  const [draft, setDraft] = useState<Partial<ProductUpsertPayload>>({})
  const [activeTab, setActiveTab] = useState<'general' | 'pricing' | 'advanced'>('general')

  const productQuery = useQuery({
    queryKey: ['product', productId],
    enabled: isEdit && Boolean(productId),
    queryFn: () => getProduct(productId!),
    staleTime: 30_000,
  })

  const formData = useMemo<ProductUpsertPayload>(() => {
    if (isEdit && productQuery.data) {
      return {
        name: productQuery.data.name || '',
        defaultCode: productQuery.data.defaultCode || '',
        barcode: productQuery.data.barcode || '',
        listPrice: productQuery.data.listPrice ?? productQuery.data.price ?? 0,
        saleOk: productQuery.data.saleOk ?? true,
        purchaseOk: productQuery.data.purchaseOk ?? true,
        active: productQuery.data.active !== false,
        description: productQuery.data.description || '',
        productType: productQuery.data.productType || 'consu',
        categoryId: productQuery.data.categoryId ?? null,
        incomeAccountId: productQuery.data.incomeAccountId ?? null,
        expenseAccountId: productQuery.data.expenseAccountId ?? null,
        saleTaxIds: productQuery.data.saleTaxIds ?? [],
        purchaseTaxIds: productQuery.data.purchaseTaxIds ?? [],
        ...draft,
      }
    }
    return { ...DEFAULT_FORM, ...draft }
  }, [draft, isEdit, productQuery.data])

  const productAdminMetaQuery = useQuery({
    queryKey: ['products', 'admin-meta'],
    queryFn: getProductAdminMeta,
    staleTime: 60_000,
    retry: 0,
  })
  const canManageAdminFields = !!productAdminMetaQuery.data?.permissions?.canManageAdminFields
  const salesTaxesQuery = useQuery({
    queryKey: ['taxes', 'product-form', 'sale'],
    queryFn: () => listVatTaxes({ typeTaxUse: 'sale', activeOnly: true, limit: 500 }),
    staleTime: 60_000,
  })
  const purchaseTaxesQuery = useQuery({
    queryKey: ['taxes', 'product-form', 'purchase'],
    queryFn: () => listVatTaxes({ typeTaxUse: 'purchase', activeOnly: true, limit: 500 }),
    staleTime: 60_000,
  })
  const saleVatDefaultAppliedRef = useRef(false)
  const purchaseVatDefaultAppliedRef = useRef(false)
  const saleVatTouchedRef = useRef(false)
  const purchaseVatTouchedRef = useRef(false)
  const saleTaxOptions = salesTaxesQuery.data?.items ?? []
  const purchaseTaxOptions = purchaseTaxesQuery.data?.items ?? []
  const defaultSaleTaxId = useMemo(() => getDefaultVatTaxId(saleTaxOptions), [saleTaxOptions])
  const defaultPurchaseTaxId = useMemo(() => getDefaultVatTaxId(purchaseTaxOptions), [purchaseTaxOptions])
  const productTabs = useMemo(
    () => [
      { key: 'general' as const, label: 'ข้อมูลทั่วไป' },
      { key: 'pricing' as const, label: 'ราคา / ภาษี' },
      { key: 'advanced' as const, label: 'ตั้งค่าขั้นสูง' },
    ],
    [],
  )

  useEffect(() => {
    if (isEdit || saleVatDefaultAppliedRef.current || saleVatTouchedRef.current) return
    if (salesTaxesQuery.isLoading) return
    if (!defaultSaleTaxId) return
    setDraft((prev) => {
      if (Array.isArray(prev.saleTaxIds) && prev.saleTaxIds.length > 0) return prev
      saleVatDefaultAppliedRef.current = true
      return { ...prev, saleTaxIds: [defaultSaleTaxId] }
    })
  }, [defaultSaleTaxId, isEdit, salesTaxesQuery.isLoading])

  useEffect(() => {
    if (isEdit || purchaseVatDefaultAppliedRef.current || purchaseVatTouchedRef.current) return
    if (purchaseTaxesQuery.isLoading) return
    if (!defaultPurchaseTaxId) return
    setDraft((prev) => {
      if (Array.isArray(prev.purchaseTaxIds) && prev.purchaseTaxIds.length > 0) return prev
      purchaseVatDefaultAppliedRef.current = true
      return { ...prev, purchaseTaxIds: [defaultPurchaseTaxId] }
    })
  }, [defaultPurchaseTaxId, isEdit, purchaseTaxesQuery.isLoading])

  const saveMutation = useMutation({
    mutationFn: async (payload: ProductUpsertPayload) => {
      if (isEdit && productId) return updateProduct(productId, payload)
      return createProduct(payload)
    },
    onSuccess: async (result) => {
      await queryClient.invalidateQueries({ queryKey: ['products'] })
      await queryClient.invalidateQueries({ queryKey: ['product', result.id] })
      toast.success(isEdit ? 'บันทึกสินค้าเรียบร้อย' : 'สร้างสินค้าสำเร็จ')
      navigate('/products', { replace: true })
    },
    onError: (err) => {
      const msg = err instanceof Error ? err.message : 'บันทึกสินค้าไม่สำเร็จ'
      setErrorText(msg)
      toast.error(msg)
    },
  })

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setErrorText(null)
    if (!formData.name.trim()) {
      setErrorText('กรุณาระบุชื่อสินค้า')
      return
    }
    await saveMutation.mutateAsync({
      ...formData,
      name: formData.name.trim(),
      defaultCode: formData.defaultCode?.trim() || undefined,
      barcode: formData.barcode?.trim() || undefined,
      description: formData.description?.trim() || undefined,
      listPrice: Number(formData.listPrice || 0),
    })
  }

  return (
    <div>
      <PageHeader
        title={isEdit ? 'แก้ไขสินค้า' : 'เพิ่มสินค้า'}
        subtitle="ตัวจัดการสินค้า/บริการสำหรับ Odoo18 (adt_th_api)"
        breadcrumb={`รายรับ · สินค้า · ${isEdit ? 'แก้ไข' : 'เพิ่ม'}`}
        actions={
          <div className="d-flex gap-2">
            <Button size="sm" variant="ghost" onClick={() => navigate('/products')}>
              ยกเลิก
            </Button>
            <Button size="sm" type="submit" form="product-form" isLoading={saveMutation.isPending}>
              บันทึก
            </Button>
          </div>
        }
      />

      {errorText ? (
        <Alert variant="danger" className="small">
          {errorText}
        </Alert>
      ) : null}

      {isEdit && productQuery.isLoading ? <div className="small text-muted">กำลังโหลดข้อมูลสินค้า...</div> : null}
      {isEdit && productQuery.isError ? (
        <Alert variant="danger" className="small">
          {productQuery.error instanceof Error ? productQuery.error.message : 'โหลดสินค้าไม่สำเร็จ'}
        </Alert>
      ) : null}

      <Form id="product-form" onSubmit={onSubmit}>
        <div className="d-flex flex-column gap-3">
          <Tabs items={productTabs} value={activeTab} onChange={setActiveTab} className="w-100" />

          <Card className="p-0 overflow-hidden">
            <div className="p-4">
                {activeTab === 'general' ? (
                  <div className="row g-3 align-items-start">
                    {isEdit && productQuery.data ? (
                      <div className="col-12 d-flex align-items-center gap-3 mb-2 pb-3 border-bottom">
                        <img
                          src={productImageSrc({
                            id: productId,
                            image128: productQuery.data.image128 || null,
                            imageUrl: productQuery.data.imageUrl || null,
                          })}
                          alt={productQuery.data.name || 'product'}
                          width={72}
                          height={72}
                          style={{ borderRadius: 10, objectFit: 'cover', border: '1px solid #e2e8f0' }}
                          onError={(e) => {
                            ;(e.currentTarget as HTMLImageElement).src = '/vite.svg'
                          }}
                        />
                        <div className="small text-muted">
                          <div>รูปสินค้าดึงจาก Odoo</div>
                          <div>
                            คงเหลือ:{' '}
                            {typeof productQuery.data.qtyAvailable === 'number'
                              ? productQuery.data.qtyAvailable.toLocaleString('th-TH', { maximumFractionDigits: 2 })
                              : '—'}
                          </div>
                        </div>
                      </div>
                    ) : null}

                    <div className="col-12">
                      <Label htmlFor="name" required>
                        ชื่อสินค้า
                      </Label>
                      <Input id="name" value={formData.name} onChange={(e) => setDraft((p) => ({ ...p, name: e.target.value }))} />
                    </div>

                    <div className="col-md-6">
                      <Label htmlFor="defaultCode">รหัสสินค้า</Label>
                      <Input
                        id="defaultCode"
                        value={formData.defaultCode || ''}
                        onChange={(e) => setDraft((p) => ({ ...p, defaultCode: e.target.value }))}
                      />
                    </div>

                    <div className="col-md-6">
                      <Label htmlFor="barcode">บาร์โค้ด</Label>
                      <Input
                        id="barcode"
                        value={formData.barcode || ''}
                        onChange={(e) => setDraft((p) => ({ ...p, barcode: e.target.value }))}
                      />
                    </div>

                    <div className="col-12">
                      <Label htmlFor="description">รายละเอียด</Label>
                      <textarea
                        id="description"
                        className="form-control"
                        rows={4}
                        value={formData.description || ''}
                        onChange={(e) => setDraft((p) => ({ ...p, description: e.target.value }))}
                        placeholder="รายละเอียดสินค้า / บันทึกเพิ่มเติม"
                      />
                    </div>
                  </div>
                ) : null}

                {activeTab === 'pricing' ? (
                  <div className="row g-3 align-items-start">
                    <div className="col-md-6">
                      <Label htmlFor="listPrice">ราคาขาย</Label>
                      <Input
                        id="listPrice"
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.listPrice ?? 0}
                        onChange={(e) => setDraft((p) => ({ ...p, listPrice: Number(e.target.value || 0) }))}
                      />
                    </div>

                    <div className="col-md-6">
                      <Label htmlFor="saleTaxId">ภาษีขาย (VAT)</Label>
                      <select
                        id="saleTaxId"
                        className="form-select"
                        value={formData.saleTaxIds?.[0] ?? ''}
                        onChange={(e) => {
                          saleVatTouchedRef.current = true
                          const taxId = e.target.value ? Number(e.target.value) : null
                          setDraft((p) => ({ ...p, saleTaxIds: taxId ? [taxId] : [] }))
                        }}
                      >
                        <option value="">— ไม่กำหนด —</option>
                        {saleTaxOptions.map((t) => (
                          <option key={`sale-tax-${t.id}`} value={t.id}>
                            {t.name} ({t.amount}%)
                          </option>
                        ))}
                      </select>
                      <div className="small text-muted mt-1">
                        {defaultSaleTaxId
                          ? `ค่าเริ่มต้น: ${saleTaxOptions.find((t) => t.id === defaultSaleTaxId)?.name ?? 'VAT 7%'}`
                          : saleTaxOptions.length > 0
                            ? 'ไม่พบ VAT 7% ในรายการนี้ ระบบจะให้เลือกจากรายการที่มีอยู่'
                            : 'ไม่พบรายการ VAT ฝั่งขายในระบบ'}
                      </div>
                    </div>

                    <div className="col-md-6">
                      <Label htmlFor="purchaseTaxId">ภาษีซื้อ (VAT)</Label>
                      <select
                        id="purchaseTaxId"
                        className="form-select"
                        value={formData.purchaseTaxIds?.[0] ?? ''}
                        onChange={(e) => {
                          purchaseVatTouchedRef.current = true
                          const taxId = e.target.value ? Number(e.target.value) : null
                          setDraft((p) => ({ ...p, purchaseTaxIds: taxId ? [taxId] : [] }))
                        }}
                      >
                        <option value="">— ไม่กำหนด —</option>
                        {purchaseTaxOptions.map((t) => (
                          <option key={`purchase-tax-${t.id}`} value={t.id}>
                            {t.name} ({t.amount}%)
                          </option>
                        ))}
                      </select>
                      <div className="small text-muted mt-1">
                        {defaultPurchaseTaxId
                          ? `ค่าเริ่มต้น: ${purchaseTaxOptions.find((t) => t.id === defaultPurchaseTaxId)?.name ?? 'VAT 7%'}`
                          : purchaseTaxOptions.length > 0
                            ? 'ไม่พบ VAT 7% ในรายการนี้ ระบบจะให้เลือกจากรายการที่มีอยู่'
                            : 'ไม่พบรายการ VAT ฝั่งซื้อในระบบ'}
                      </div>
                    </div>
                  </div>
                ) : null}

                {activeTab === 'advanced' ? (
                  canManageAdminFields ? (
                    <div className="row g-3 align-items-start">
                      <div className="col-md-4">
                        <Label htmlFor="productType">ชนิดสินค้า</Label>
                        <select
                          id="productType"
                          className="form-select"
                          value={formData.productType || 'consu'}
                          onChange={(e) => setDraft((p) => ({ ...p, productType: e.target.value as any }))}
                        >
                          {(productAdminMetaQuery.data?.productTypes || []).map((t) => (
                            <option key={t.id} value={t.id}>
                              {t.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-md-8">
                        <Label htmlFor="categoryId">Category</Label>
                        <select
                          id="categoryId"
                          className="form-select"
                          value={formData.categoryId ?? ''}
                          onChange={(e) => setDraft((p) => ({ ...p, categoryId: e.target.value ? Number(e.target.value) : null }))}
                        >
                          <option value="">— เลือก Category —</option>
                          {(productAdminMetaQuery.data?.categories || []).map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-md-6">
                        <Label htmlFor="incomeAccountId">บัญชีรายได้ (Income Account)</Label>
                        <select
                          id="incomeAccountId"
                          className="form-select"
                          value={formData.incomeAccountId ?? ''}
                          onChange={(e) => setDraft((p) => ({ ...p, incomeAccountId: e.target.value ? Number(e.target.value) : null }))}
                        >
                          <option value="">— ใช้ค่าจาก Category/Default —</option>
                          {(productAdminMetaQuery.data?.accounts || []).map((a) => (
                            <option key={`inc-${a.id}`} value={a.id}>
                              [{a.code}] {a.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="col-md-6">
                        <Label htmlFor="expenseAccountId">บัญชีค่าใช้จ่าย (Expense Account)</Label>
                        <select
                          id="expenseAccountId"
                          className="form-select"
                          value={formData.expenseAccountId ?? ''}
                          onChange={(e) => setDraft((p) => ({ ...p, expenseAccountId: e.target.value ? Number(e.target.value) : null }))}
                        >
                          <option value="">— ใช้ค่าจาก Category/Default —</option>
                          {(productAdminMetaQuery.data?.accounts || []).map((a) => (
                            <option key={`exp-${a.id}`} value={a.id}>
                              [{a.code}] {a.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  ) : (
                    <div className="small text-muted">
                      ผู้ใช้ปัจจุบันไม่มีสิทธิ์จัดการ field ขั้นสูง (ชนิดสินค้า / category / ผูกบัญชี)
                    </div>
                  )
                ) : null}
            </div>
          </Card>

          <Card className="p-0 overflow-hidden">
            <div className="px-4 py-3 border-bottom">
              <div className="qf-section-title mb-0">ตั้งค่า</div>
            </div>
            <div className="p-4">
                <div className="row g-3">
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        id="saleOk"
                        className="form-check-input"
                        type="checkbox"
                        checked={Boolean(formData.saleOk)}
                        onChange={(e) => setDraft((p) => ({ ...p, saleOk: e.target.checked }))}
                      />
                      <label className="form-check-label" htmlFor="saleOk">
                        ใช้งานขาย (Sale)
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        id="purchaseOk"
                        className="form-check-input"
                        type="checkbox"
                        checked={Boolean(formData.purchaseOk)}
                        onChange={(e) => setDraft((p) => ({ ...p, purchaseOk: e.target.checked }))}
                      />
                      <label className="form-check-label" htmlFor="purchaseOk">
                        ใช้งานซื้อ (Purchase)
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        id="active"
                        className="form-check-input"
                        type="checkbox"
                        checked={Boolean(formData.active)}
                        onChange={(e) => setDraft((p) => ({ ...p, active: e.target.checked }))}
                      />
                      <label className="form-check-label" htmlFor="active">
                        ใช้งาน (Active)
                      </label>
                    </div>
                  </div>
                </div>
            </div>
          </Card>

          <Card className="p-0 overflow-hidden">
            <div className="px-4 py-3 border-bottom">
              <div className="qf-section-title mb-0">สิทธิ์ / Metadata</div>
            </div>
            <div className="p-4">
                <div className="small">
                  <div className="fw-semibold mb-1">โหมด Admin สำหรับสินค้า</div>
                  {productAdminMetaQuery.isLoading ? (
                    <div className="text-muted">กำลังโหลดสิทธิ์และ metadata...</div>
                  ) : canManageAdminFields ? (
                    <div className="text-success">สามารถตั้งค่า ชนิดสินค้า / category / ภาษี VAT / บัญชีสินค้า ได้</div>
                  ) : (
                    <div className="text-muted">
                      ผู้ใช้ปัจจุบันไม่มีสิทธิ์จัดการ field ขั้นสูง (ชนิดสินค้า / category / ผูกบัญชี)
                    </div>
                  )}
                </div>
            </div>
          </Card>
        </div>
      </Form>
    </div>
  )
}
